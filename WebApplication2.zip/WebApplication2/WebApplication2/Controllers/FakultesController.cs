﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class FakultesController : Controller
    {
        private readonly OkulContext _context;

        public FakultesController(OkulContext context)
        {
            _context = context;
        }

        // GET: Fakultes
        public async Task<IActionResult> Index()
        {
            return View(await _context.Fakulteler.ToListAsync());
        }

        // GET: Fakultes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fakulte = await _context.Fakulteler
                .FirstOrDefaultAsync(m => m.FakulteID == id);
            if (fakulte == null)
            {
                return NotFound();
            }

            return View(fakulte);
        }

        // GET: Fakultes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Fakultes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("FakulteID,FakulteAd")] Fakulte fakulte)
        {
            if (ModelState.IsValid)
            {
                _context.Add(fakulte);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(fakulte);
        }

        // GET: Fakultes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fakulte = await _context.Fakulteler.FindAsync(id);
            if (fakulte == null)
            {
                return NotFound();
            }
            return View(fakulte);
        }

        // POST: Fakultes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("FakulteID,FakulteAd")] Fakulte fakulte)
        {
            if (id != fakulte.FakulteID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(fakulte);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FakulteExists(fakulte.FakulteID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(fakulte);
        }

        // GET: Fakultes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fakulte = await _context.Fakulteler
                .FirstOrDefaultAsync(m => m.FakulteID == id);
            if (fakulte == null)
            {
                return NotFound();
            }

            return View(fakulte);
        }

        // POST: Fakultes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var fakulte = await _context.Fakulteler.FindAsync(id);
            if (fakulte != null)
            {
                _context.Fakulteler.Remove(fakulte);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FakulteExists(int id)
        {
            return _context.Fakulteler.Any(e => e.FakulteID == id);
        }
    }
}

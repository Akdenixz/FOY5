﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Models;
using WebApplication2.Data;

namespace WebApplication2.Controllers
{
    public class OgrenciDersController : Controller
    {
        private readonly OkulContext _context;

        public OgrenciDersController(OkulContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(int? yil, string yariyil)
        {
            var ogrenciDersler = _context.OgrenciDersler
                .Include(od => od.Ogrenci)
                .Include(od => od.Ders)
                .AsQueryable();

            // Yıl filtreleme
            if (yil.HasValue)
            {
                ogrenciDersler = ogrenciDersler.Where(od => od.Yil == yil.ToString());
            }

            // Yarıyıl filtreleme
            if (!string.IsNullOrEmpty(yariyil))
            {
                ogrenciDersler = ogrenciDersler.Where(od => od.Yariyil == yariyil);
            }

            // ViewBag ile filtre seçeneklerini dropdown için gönder
            ViewBag.Yillar = new SelectList(Enumerable.Range(2020, 7)); // 2020 - 2026
            ViewBag.Yariyillar = new SelectList(new List<string> { "Güz", "Bahar" });

            return View(await ogrenciDersler.ToListAsync());
        }

        public async Task<IActionResult> Create()
        {
            ViewBag.Ogrenciler = new SelectList(await _context.Ogrenciler.ToListAsync(), "OgrenciID", "Ad");
            ViewBag.Dersler = new SelectList(await _context.Dersler.ToListAsync(), "DersID", "DersAd");
            ViewBag.Yariyillar = new SelectList(new List<string> { "Güz", "Bahar" });
            ViewBag.Yillar = new SelectList(Enumerable.Range(2020, 7)); // 2020 - 2026
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(OgrenciDers ogrenciDers)
        {
            if (ModelState.IsValid)
            {
                _context.Add(ogrenciDers);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewBag.Ogrenciler = new SelectList(await _context.Ogrenciler.ToListAsync(), "OgrenciID", "Ad", ogrenciDers.OgrenciID);
            ViewBag.Dersler = new SelectList(await _context.Dersler.ToListAsync(), "DersID", "DersAd", ogrenciDers.DersID);
            ViewBag.Yariyillar = new SelectList(new List<string> { "Güz", "Bahar" }, ogrenciDers.Yariyil);
            ViewBag.Yillar = new SelectList(Enumerable.Range(2020, 7), ogrenciDers.Yil);
            return View(ogrenciDers);
        }

        public async Task<IActionResult> Delete(int ogrenciID, int dersID)
        {
            var ogrenciDers = await _context.OgrenciDersler
                .FirstOrDefaultAsync(od => od.OgrenciID == ogrenciID && od.DersID == dersID);

            if (ogrenciDers != null)
            {
                _context.OgrenciDersler.Remove(ogrenciDers);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int ogrenciID, int dersID)
        {
            var ogrenciDers = await _context.OgrenciDersler
                .FirstOrDefaultAsync(od => od.OgrenciID == ogrenciID && od.DersID == dersID);

            if (ogrenciDers == null)
            {
                return NotFound();
            }

            ViewBag.Ogrenciler = new SelectList(await _context.Ogrenciler.ToListAsync(), "OgrenciID", "Ad", ogrenciDers.OgrenciID);
            ViewBag.Dersler = new SelectList(await _context.Dersler.ToListAsync(), "DersID", "DersAd", ogrenciDers.DersID);
            ViewBag.Yariyillar = new SelectList(new List<string> { "Güz", "Bahar" }, ogrenciDers.Yariyil);
            ViewBag.Yillar = new SelectList(Enumerable.Range(2020, 7), ogrenciDers.Yil);
            return View(ogrenciDers);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int ogrenciID, int dersID, OgrenciDers ogrenciDers)
        {
            if (ogrenciID != ogrenciDers.OgrenciID || dersID != ogrenciDers.DersID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(ogrenciDers);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.OgrenciDersler.Any(e => e.OgrenciID == ogrenciDers.OgrenciID && e.DersID == ogrenciDers.DersID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            ViewBag.Ogrenciler = new SelectList(await _context.Ogrenciler.ToListAsync(), "OgrenciID", "Ad", ogrenciDers.OgrenciID);
            ViewBag.Dersler = new SelectList(await _context.Dersler.ToListAsync(), "DersID", "DersAd", ogrenciDers.DersID);
            ViewBag.Yariyillar = new SelectList(new List<string> { "Güz", "Bahar" }, ogrenciDers.Yariyil);
            ViewBag.Yillar = new SelectList(Enumerable.Range(2020, 7), ogrenciDers.Yil);
            return View(ogrenciDers);
        }
        // GET: OgrenciDers/OgrenciDersleri?ogrenciID=1
        public async Task<IActionResult> OgrenciDersleri(int? ogrenciID)
        {
            if (!ogrenciID.HasValue)
            {
                ViewBag.Hata = "Lütfen geçerli bir öğrenci ID'si giriniz.";
                return View(new List<OgrenciDers>());
            }

            var ogrenci = await _context.Ogrenciler
                .FirstOrDefaultAsync(o => o.OgrenciID == ogrenciID);

            if (ogrenci == null)
            {
                ViewBag.Hata = "Girilen ID'ye ait öğrenci bulunamadı.";
                return View(new List<OgrenciDers>());
            }

            var dersler = await _context.OgrenciDersler
                .Include(od => od.Ders)
                .Where(od => od.OgrenciID == ogrenciID)
                .ToListAsync();

            ViewBag.OgrenciAd = ogrenci.Ad;
            ViewBag.OgrenciID = ogrenciID;

            return View(dersler);
        }
        // GET: NotGiris
        public async Task<IActionResult> NotGiris(int dersID)
        {
            var ogrenciDersler = await _context.OgrenciDersler
                .Include(od => od.Ogrenci)
                .Include(od => od.Ders)
                .Where(od => od.DersID == dersID)
                .ToListAsync();

            // Öğrenciler için ders bilgisi ve notları getiriliyor.
            return View(ogrenciDersler);
        }

        // POST: NotGiris
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> NotGiris(List<OgrenciDers> ogrenciDersler)
        {
            if (ogrenciDersler != null && ogrenciDersler.Any())
            {
                foreach (var item in ogrenciDersler)
                {
                    var mevcut = await _context.OgrenciDersler
                        .FirstOrDefaultAsync(x => x.OgrenciID == item.OgrenciID && x.DersID == item.DersID);

                    if (mevcut != null)
                    {
                        mevcut.Vize = item.Vize;
                        mevcut.Final = item.Final;
                        _context.Update(mevcut);
                    }
                }

                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewBag.Hata = "Notlar güncellenirken bir hata oluştu.";
            return View(ogrenciDersler);
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Views.Ders
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

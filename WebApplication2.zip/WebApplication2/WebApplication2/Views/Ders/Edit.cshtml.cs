using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Views.Ders
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

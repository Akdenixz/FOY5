using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Views.Ogrencis
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
